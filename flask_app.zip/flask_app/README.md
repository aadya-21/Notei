# NOTEi

### Video Demo: <URL HERE>

### Description:

notei is my final project of the CS50 Introduction to Computer Science online course from Harvard / edx.

it is a notes app allows a user to sign in and create an account and then he/she can create new notes, access old ones and delete notes.

it uses a database to store all the notes and the information of the users.

### Technology used:

- python
- flask
- sqlite
- html
- css
- bootstrap
- databases

### Features:

- Sign-up:
  - register new users to start creating notes.
- Login:
  - login to an existing user account.
- Logout:
  - logout from an account
- delete :
  - delete an existing note.
- homepage :
  - displays previous notes as well as a section to add new note and delete existing notes

### FILES :

- main.py - main file that creates the app and debugs it for it to start running
- website : a folder that has a bunch of files and sub folders that define the behaviour of the website as well as define what it looks like
  - **init**.py - a file in website that allows us to import all the essential features like sql and as well as routing the login/logout pages so that everything works appropriately.
  - views.py - a file in website that contains all the code related to the behaviour of the note like how to delete and what to do if the note is too short.
  - models.py - a file in website that contains the code for the database that we have created. it contains the tables for storing the data of the users and as well as notes.
  - auth.py - contains the code for the routing of the the login/logout and the sign-up pages, there were also the codes for checking the validity of the password and message flashing
  - templates - a subfolder that has a bunch of templates that form the structure of the website :
    - base.html - has the basic skeleton of the website and the code is extended to the rest of the templates
    - home.html - has the code for the homepage
    - login.html - has the code for the login page
    - sign-up.html - has the code for the sign-up page
  - static - a subfolder that contains the things that never change throughout the program it has an index.js file that contains the code for deleting a folder from the database

### Special Thanks.

I want to thank all who participated on this project. My family support that has no limits, my mom who always listened and stayed with me no matter what.
my friend who taught me a lot and brought me to light when I needed.
And the CS50 Crew that helped me become better than I was on Week 0.
